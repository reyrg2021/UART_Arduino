Null-modem emulator (com0com) is an open source kernel-mode virtual serial port driver for Windows, available freely under GPL license.

The HUB for communications (hub4com) is a Windows application and is a part of the com0com project.

The homepage for com0com project is http://com0com.sourceforge.net/.

How to use: https://vovsoft.com/blog/how-to-sniff-serial-port-communication/
